/*
	Component i Service en Angular 2 
	@author sergi grau, sergi.grau@fje.edu
	@version 1.0
	date 20.01.2016
	format del document UTF-8

	CHANGELOG
	20.01.2016
	Component que mostra l'arquitectura d'Angular 2

	NOTES
	ORIGEN
    Desenvolupament Aplicacions Web. Jesuïtes el Clot
*/

//un servei és una classe amb un propòsit concret.
//Normalment la lògica de la applicació
function Service() {};

Service.prototype.nom = function () {
    return 'Servei en Angular';
};

var Cmp = ng.core.
Component({
    selector: 'aplicacio',
    viewInjector: [Service]
}).
View({
    template: '{{nom}} 2!'
}).
Class({
    constructor: [Service, function Cmp(service) {
        this.nom = service.nom();
    }]
});

document.addEventListener('DOMContentLoaded', function () {
    ng.platform.browser.bootstrap(Cmp, Service);

});