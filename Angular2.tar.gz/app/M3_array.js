/*
	Component en Angular 2, que itera per una matriu
    Utilitzem la directiva NgFor, ara està al core i no cal importar-la
	@author sergi grau, sergi.grau@fje.edu
	@version 1.0
	date 20.01.2016
	format del document UTF-8

	CHANGELOG
	20.01.2016
	Component en Angular 2, que itera per una matriu

	NOTES
	ORIGEN
    Desenvolupament Aplicacions Web. Jesuïtes el Clot
*/


function Component() {
    this.nom = "Sergi";
    this.cursos = ["DAW", "DAM", "ASIX"];
}

Component.annotations = [

  new ng.core.ComponentMetadata({
        selector: "aplicacio"
    }),
  new ng.core.ViewMetadata({
      template: '<p>Nom: {{ nom }}</p>' +
            '<p>Cursos:</p>' +
            '<ul>' +
            '<li *ngFor="#curs of cursos">' +
            '{{ curs }}' +
            '</li>' +
            '</ul>'
    })
];

// Bootstrapping
document.addEventListener('DOMContentLoaded', function () {
    ng.platform.browser.bootstrap(Component);
});