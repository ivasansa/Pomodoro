/*
	Us d'entrades
	@author sergi grau, sergi.grau@fje.edu
	@version 1.0
	date 20.01.2016
	format del document UTF-8

	CHANGELOG
	20.01.2016
	Us d'entrades

	NOTES
	ORIGEN
    Desenvolupament Aplicacions Web. Jesuïtes el Clot
*/

function LlistaCursos() {
    this.cursos = ["ASIX", "DAW", "DAM"];
    this.afegirCurs = function (curs) {
        this.cursos.push(curs);
    };
    this.escriure = function ($event) {
        console.log('escriu' + $event.target.value);

        if ($event.which === 13) {
            this.afegirCurs($event.target.value);
            $event.target.value = null;
        }
    }
}

LlistaCursos.annotations = [
  new ng.core.ComponentMetadata({
        selector: "aplicacio"
    }),
  new ng.core.ViewMetadata({
        templateUrl: 'app/M7_template.html',
    })
];
document.addEventListener("DOMContentLoaded", function () {
    ng.platform.browser.bootstrap(LlistaCursos);

});