/*
	Exemple de pipes
    @author sergi grau, sergi.grau@fje.edu
	@version 1.0
	date 20.01.2016
	format del document UTF-8

	CHANGELOG
	20.01.2016
	Exemple de pipes

	NOTES
	ORIGEN
    Desenvolupament Aplicacions Web. Jesuïtes el Clot
*/
function App() {
    this.frase = `Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,proident, sunt in culpa qui officia deserunt mollit anim id est laborum.`;
}

App.annotations = [
			new ng.core.Component({
        selector: "aplicacio"
    }),
            new ng.core.View({
        pipes: [PipePersonalitzada],
        templateUrl: 'app/M6_template.html',
    })
		];

function PipePersonalitzada() {
    this.transform = function (value, args) {
        var paraules = value.split(" ");
        paraules = paraules.slice(0, args[0]);
        var novaCadena = paraules.join(" ") + "...";
        return novaCadena;
    }
}

PipePersonalitzada.annotations = [
			new ng.core.Pipe({
        name: "limitaParaules"
    })
		];

document.addEventListener("DOMContentLoaded",
    function () {
        ng.platform.browser.bootstrap(App);

    }
)