/*
	Component en Angular 2, que itera per una matriu
    Utilitzem la directiva NgFor, i fa servir una plantilla
	@author sergi grau, sergi.grau@fje.edu
	@version 1.0
	date 20.01.2016
	format del document UTF-8

	CHANGELOG
	20.01.2016
	Component en Angular 2, que itera per una matriu

	NOTES
	ORIGEN
    Desenvolupament Aplicacions Web. Jesuïtes el Clot
*/

(function(app) {
  app.AppComponent =
    ng.core.Component({
      selector: 'aplicacio',
      templateUrl: 'app/M4_template.html',
    })
    .Class({
      constructor: function() {
        this.professor = 'Sergi Grau';
        this.cursos = ['DAW', 'DAM', 'ASIX'];
      }
    });
})(window.app || (window.app = {}));