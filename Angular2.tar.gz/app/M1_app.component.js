/*
	Component en Angular 2
	@author sergi grau, sergi.grau@fje.edu
	@version 1.0
	date 20.01.2016
	format del document UTF-8

	CHANGELOG
	20.01.2016
	Component que mostra l'arquitectura d'Angular 2

	NOTES
	ORIGEN
    Desenvolupament Aplicacions Web. Jesuïtes el Clot
*/

(function (app) {
    app.AppComponent =
        ng.core.Component({
            selector: 'appProva',
            template: '<h1>Primera aplicació amb Angular2, {{nom}}</h1>'
        })
        .Class({
            constructor: function () {
                this.nom = "HOY"
            }
        });
})(window.app || (window.app = {}));