/*
	propietats amb Angular
	@author sergi grau, sergi.grau@fje.edu
	@version 1.0
	date 20.01.2016
	format del document UTF-8

	CHANGELOG
	20.01.2016
	Component que mostra l'arquitectura d'Angular 2

	NOTES
	ORIGEN
    Desenvolupament Aplicacions Web. Jesuïtes el Clot
*/

function Component() {
    this.nom = "Sergi";
}

Component.annotations = [

  new ng.core.ComponentMetadata({ // o ng.core.Component
        selector: "aplicacio"
    }),
  new ng.core.ViewMetadata({ // o ng.core.View
        template: '<p>El nom és: {{ nom }}</p>'
    })
];

// Bootstrapping
document.addEventListener('DOMContentLoaded', function () {
    ng.platform.browser.bootstrap(Component);
});